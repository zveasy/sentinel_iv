from hb.adapters import cmapss_common


def parse(path):
    return cmapss_common.parse(path)
