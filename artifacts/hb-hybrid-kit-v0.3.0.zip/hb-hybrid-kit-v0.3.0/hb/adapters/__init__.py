# Adapter plugins package.
