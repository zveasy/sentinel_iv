"""Core APIs for Harmony Bridge (stable integration surface)."""
