"""Local web server entry points for the Hybrid Kit."""
